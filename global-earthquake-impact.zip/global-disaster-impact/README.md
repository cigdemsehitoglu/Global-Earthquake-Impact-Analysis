# Global Earthquake Impact Analysis

**Public Health Toll and Economic Losses from Major Seismic Events**

Created: October 7, 2026

## Description
A reproducible analysis that ranks earthquake-related impact categories by:
- Public health burden (fatalities + injuries)
- Economic losses (billion USD)

Interactive Plotly bar charts make the rankings easy to explore.

This project is intentionally different from the classic NOAA Storm Database assignment while following a similar analytical structure (health vs economic consequences).

## Deploy to GitHub Pages
1. Upload `index.html` to a new public repository
2. Settings → Pages → Source: main / root → Save
3. Use the generated link for your assignment
